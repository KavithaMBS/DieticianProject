'''
Created on Jun 15, 2022

@author: KAVITHA
'''
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
import time
driver= webdriver.Chrome(ChromeDriverManager().install())
lines=[]
with open("Latin.txt","r",encoding="utf-8") as fp:
    lines=fp.readlines()

with open("translater.txt","w",encoding="utf-8") as fp:pass

#search_url="https://translate.google.co.in/?sl=en&tl=hi&text={q}&op=translate"
#search_url="https://translate.google.com/?sl=la&tl=en&text={q}&op=translate"
search_url="https://translate.google.com/?sl=la&tl=ro&text=Lorem%20ipsum%20dolor%20sit%20amet%2C%20consectetur%20adipiscing%20elit.%20Nunc%20ullamcorper%0Acondimentum%20euismod%20ornare%20laoreet.%20Quisque%20vel%20efficitur%0AQuam%20belle%20molestiam.%20Vivamus%20in%20hac%20platea%0Asapien%20est%2C%20aliquet%20non%20mauris%20sit%20amet%2C%20tempor%20tempus%20leo.&op=translate"

for line in lines:
    line=line.strip()
    line=line.replace("</string>","")
    line= line.split(">")
# print(line[0],line[1])
print(line[0])
driver.get(search_url.format(q=line[0]))

time.sleep(15)
for elements in driver.find_elements_by_xpath('//span[@class="Y2IQFc"]'):
#for elements in driver.find_elements_by_xpath('//*[@id="tw-target-text"]/span'):
#for elements in driver.find_elements_by_xpath('/html/body/div[7]/div/div[10]/div[1]/div[2]/div[2]/div/div/div[1]/div/div/div[1]/g-expandable-container/div/div/div[3]/div[3]/div/div[2]/div[1]/pre/span'):
    print(line[0]+">"+elements.text+"</string>")
with open("translater.txt", "a",encoding="utf-8") as fp:
    fp.writelines((line[0]+">"+elements.text+"</string>\n"))
